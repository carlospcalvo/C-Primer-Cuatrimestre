int sumar(int a, int b);
