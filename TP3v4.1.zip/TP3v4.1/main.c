#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.csv (modo binario).
    10. Salir
*****************************************************/


int main()
{
    int option = 0;
    LinkedList* listaEmpleados = ll_newLinkedList();

    do{
        switch(menu(&option))
        {
            case 1:
                system("cls");
                if(controller_loadFromText("data_test2.csv", listaEmpleados) != 0)
                {
                    printf("data_test2.csv cargado exitosamente. \n");
                }
                else
                {
                    printf("No se pudo cargar data_test2.csv\n");
                }
                system("pause");
                break;
            case 2:
                system("cls");
                if(controller_loadFromBinary("data.bin", listaEmpleados))
                {
                    printf("data.bin cargado exitosamente.\n");
                }
                else
                {
                    printf("No se pudo cargar data.bin\n");
                }
                system("pause");
                break;
            case 3:
                if(controller_addEmployee(listaEmpleados))
                {
                    printf("Empleado agregado exitosamente.\n");
                }
                else
                {
                    printf("No se pudo agregar el empleado. \n");
                }
                system("pause");
                break;
            case 4:
                controller_editEmployee(listaEmpleados);
                system("pause");
                break;
            case 5:
                controller_removeEmployee(listaEmpleados);
                system("pause");
                break;
            case 6:
                controller_ListEmployee(listaEmpleados);
                system("pause");
                break;
            case 7:
                controller_sortEmployee(listaEmpleados);
                break;
            case 8:
                system("cls");
                if(controller_saveAsText("data_test3.csv", listaEmpleados))
                {
                    printf("Datos guardados en data_test3.csv exitosamente.\n");
                }
                else
                {
                    printf("No se pudo guardar los datos en data_test3.csv");
                }
                system("pause");
                break;
            case 9:
                system("cls");
                if(controller_saveAsBinary("data.bin", listaEmpleados))
                {
                    printf("Datos guardados en data.bin exitosamente.\n");
                }
                else
                {
                    printf("No se pudo guardar los datos en data.bin");
                }
                system("pause");
                break;
        }
    }while(option != 10);

    ll_deleteLinkedList(listaEmpleados);
    return 0;
}
