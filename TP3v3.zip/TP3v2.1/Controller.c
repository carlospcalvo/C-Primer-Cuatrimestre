#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Employee.h"
#include "parser.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListEmployee)
{
    int todoOk = 0;

    if(path != NULL && pArrayListEmployee != NULL && ll_isEmpty(pArrayListEmployee))
    {
        FILE* f = fopen(path, "r");

        if(parser_EmployeeFromText(f, pArrayListEmployee))
        {
            todoOk = 1;
        }
    }

    return todoOk;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee)
{
    int todoOk = 0;

    if(path != NULL && pArrayListEmployee != NULL && ll_isEmpty(pArrayListEmployee))
    {
        FILE* f = fopen(path, "rb");
        if(parser_EmployeeFromBinary(f, pArrayListEmployee))
        {
            todoOk = 1;
        }
    }

    return todoOk;
}

/** \brief Alta de empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    int idAux = 0;
    char* nombreAux;
    int horasAux;
    int sueldoAux;
    char* idStr;
    char* horasTrabajadasStr;
    char* sueldoStr;
    Employee* nuevo = employee_new();

    system("cls");

    printf("*****Nuevo empleado*****");

    idAux = ll_len(pArrayListEmployee) + 1;

    printf("Ingrese nombre: ");
    fflush(stdin);
    gets(nombreAux);
    while(!(strlen(nombreAux)<128))
    {
        printf("Nombre demasiado largo. Reingrese: ");
        fflush(stdin);
        gets(nombreAux);
    }

    printf("Ingrese cantidad de horas trabajadas: ");
    fflush(stdin);
    scanf("%d", &horasAux);
    while(horasAux < 0)
    {
        printf("La cantidad de horas trabajadas debe ser igual o menor a 0(cero). Reingrese: ");
        fflush(stdin);
        scanf("%d", &horasAux);
    }

    printf("Ingrese sueldo: ");
    fflush(stdin);
    scanf("%d", &sueldoAux);
    while(sueldoAux < 0)
    {
        printf("El sueldo debe ser igual o menor a 0(cero). Reingrese: ");
        fflush(stdin);
        scanf("%d", &sueldoAux);
    }

    sprintf(idStr, "%d", idAux);
    itoa(idAux, idStr, 10);
    itoa(horasAux,horasTrabajadasStr, 10);
    itoa(sueldoAux,sueldoStr, 10);

    nuevo = employee_newParametros(idStr, nombreAux, horasTrabajadasStr, sueldoStr);

    return todoOk;
}

/** \brief Modificar datos de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Listar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    Employee* empleadoAux = NULL;

    system("cls");

    printf("ll_len: %d\n", ll_len(pArrayListEmployee));//eliminar, testing

    if(pArrayListEmployee != NULL && ll_len(pArrayListEmployee) > 0)
    {
        printf("Id                  Nombre    Horas Trabajadas      Sueldo\n\n");
        for(int i=0; i < ll_len(pArrayListEmployee); i++)
        {
            empleadoAux = (Employee*) ll_get(pArrayListEmployee, i);
            employee_print(empleadoAux);
        }
        todoOk = 1;
    }
    else
    {
        printf("No hay empleados que mostrar. \n");
    }

    return todoOk;
}

/** \brief Ordenar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListEmployee) //FUNCIONA BIEN, EL PROBLEMA ES CON EL .BIN
{
    int todoOk = 0;
    int cant;
    int tam = ll_len(pArrayListEmployee);
    FILE* f;
    Employee* auxEmp;

    if(pArrayListEmployee != NULL && path != NULL && tam > 0)
    {
        f = fopen(path, "w");
        if(f == NULL)
        {
            return todoOk;
        }

        fprintf(f, "ID,Nombre,Horas trabajadas,Sueldo\n");

        for(int i=0; i<tam; i++)
        {
            auxEmp = (Employee*) ll_get(pArrayListEmployee, i);
            cant = fprintf(f, "%d, %s, %d, %d\n",
                            auxEmp->id,
                            auxEmp->nombre,
                            auxEmp->horasTrabajadas,
                            auxEmp->sueldo);

            if (cant < 1)
            {
                return todoOk;
            }
        }
        todoOk = 1;
    }
    fclose(f);

    return todoOk;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsBinary(char* path , LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    int cant;
    int tam = ll_len(pArrayListEmployee);
    FILE* f;

    if(pArrayListEmployee != NULL && path != NULL && tam > 0)
    {
        f = fopen(path, "wb");
        if(f == NULL)
        {
            return todoOk;
        }
        for(int i=0; i<tam; i++)
        {
            cant = fwrite(ll_get(pArrayListEmployee, i), sizeof(Employee), 1, f);

            if (cant < 1)
            {
                return todoOk;
            }
        }
        fclose(f);
        todoOk = 1;
    }

    return todoOk;
}
