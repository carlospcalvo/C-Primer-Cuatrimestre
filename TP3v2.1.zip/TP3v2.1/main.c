#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.csv (modo binario).
    10. Salir
*****************************************************/


int main()
{
    int option = 0;
    LinkedList* listaEmpleados = ll_newLinkedList();
//    option = menu();

    do{
        switch(menu(&option))
        {
            case 1:
                system("cls");
                if(controller_loadFromText("data_original.csv", listaEmpleados) > 0)
                {
                    printf("data_original.csv cargado exitosamente. \n");
                }
                else
                {
                    printf("No se pudo cargar data_original.csv\n");
                }
                system("pause");
                break;
            case 2:
                if(controller_loadFromBinary("data_test1.bin", listaEmpleados) > 0)
                {
                    printf("data_test1.bin cargado exitosamente.\n");
                }
                else
                {
                    printf("No se pudo cargar data_test1.bin\n");
                }
                system("pause");
                break;
            case 3:
                controller_addEmployee(listaEmpleados);
                break;
            case 4:
                controller_editEmployee(listaEmpleados);
                break;
            case 5:
                controller_removeEmployee(listaEmpleados);
                break;
            case 6:
                controller_ListEmployee(listaEmpleados);
                system("pause");
                break;
            case 7:
                controller_sortEmployee(listaEmpleados);
                break;
            case 8:
                if(controller_saveAsText("data_test1.csv", listaEmpleados))
                {
                    printf("\nDatos guardados en data_test.csv exitosamente.\n");
                }
                else
                {
                    printf("No se pudo guardar los datos en data_test.csv");
                }
                system("pause");
                break;
            case 9:
                if(controller_saveAsBinary("data_test1.bin", listaEmpleados))
                {
                    printf("\nDatos guardados en data.bin exitosamente.\n");
                }
                else
                {
                    printf("No se pudo guardar los datos en data.bin");
                }
                system("pause");
                break;
        }
    }while(option != 10);
    return 0;
}
