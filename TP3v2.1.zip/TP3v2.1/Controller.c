#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Employee.h"
#include "parser.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListEmployee)
{
    FILE* f = fopen(path, "r");

    parser_EmployeeFromText(f, pArrayListEmployee);

    return 1;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee)
{
    int todoOk = 0;

    if(path != NULL && pArrayListEmployee != NULL)
    {
        FILE* f = fopen(path, "rb");
        if(parser_EmployeeFromBinary(f, pArrayListEmployee))
        {
            todoOk = 1;
        }
    }
    else
    {
        printf("No se pudo abrir el archivo\n");
        system("pause");
    }

    return todoOk;
}

/** \brief Alta de empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Modificar datos de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Listar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    Employee* empleadoAux = NULL;

    system("cls");

    printf("ll_len: %d\n", ll_len(pArrayListEmployee));//eliminar, testing

    if(pArrayListEmployee != NULL && ll_len(pArrayListEmployee) > 0)
    {
        printf("Id                  Nombre    Horas Trabajadas      Sueldo\n\n");
        for(int i=0; i < ll_len(pArrayListEmployee); i++)
        {
            empleadoAux = (Employee*) ll_get(pArrayListEmployee, i);
            employee_print(empleadoAux);
        }
        todoOk = 1;
    }
    else
    {
        printf("No hay empleados que mostrar. \n");
    }

    return todoOk;
}

/** \brief Ordenar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    int cant;
    int tam = ll_len(pArrayListEmployee);
    FILE* f;
    Employee* auxEmp;

    if(pArrayListEmployee != NULL && path != NULL && tam > 0)
    {
        f = fopen(path, "w");
        if(f == NULL)
        {
            return todoOk;
        }

        fprintf(f, "ID,Nombre,Horas trabajadas,Sueldo\n");

        for(int i=0; i<tam; i++)
        {
            auxEmp = (Employee*) ll_get(pArrayListEmployee, i);
            cant = fprintf(f, "%d, %s, %d, %d\n",
                            auxEmp->id,
                            auxEmp->nombre,
                            auxEmp->horasTrabajadas,
                            auxEmp->sueldo);

            if (cant < 1)
            {
                return todoOk;
            }
        }
        todoOk = 1;
    }
    fclose(f);

    return todoOk;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsBinary(char* path , LinkedList* pArrayListEmployee) //FUNCIONA BIEN, EL PROBLEMA ES CON EL .BIN
{
    int todoOk = 0;
    int cant;
    int tam = ll_len(pArrayListEmployee);
    FILE* f;

    if(pArrayListEmployee != NULL && path != NULL && tam > 0)
    {
        f = fopen(path, "wb");
        if(f == NULL)
        {
            return todoOk;
        }
        for(int i=0; i<tam; i++)
        {
            cant = fwrite((pArrayListEmployee + i), sizeof(LinkedList), 1, f);
            if (cant < 1)
            {
                return todoOk;
            }
        }
        fclose(f);
        todoOk = 1;
    }

    return todoOk;
}
